# Week 5 Assignment - Grader Account Information

## Required Grader Accounts

The following accounts have been created for grader access:

### Basic Client Account
- **Email**: basic@340.edu
- **Password**: I@mABas1cCl!3nt
- **Role**: Client

### Employee Account  
- **Email**: happy@340.edu
- **Password**: I@mAnEmpl0y33
- **Role**: Employee

### Manager Account (For Inventory Management Access)
- **Email**: manager@340.edu  
- **Password**: I@mAnAdm!n1strat0r
- **Role**: Admin

## Important Notes
- Use the **Manager account** (manager@340.edu) to access inventory management features
- All accounts are set up in both local and Render databases
- Authentication system includes JWT tokens and role-based authorization

## Assignment 5 Features Implemented
- Complete user registration and login system
- JWT token-based authentication  
- Role-based authorization (Client, Employee, Admin)
- Dynamic header navigation based on login state
- Account management and update functionality
- Password hashing with bcrypt
- Input validation and error handling
