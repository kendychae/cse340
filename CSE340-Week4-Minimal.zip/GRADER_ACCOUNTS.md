# GRADER ACCOUNTS - Week 4 Assignment (MINIMAL)

## Login Credentials for Instructors

### Account Access Information
1. **Basic Client**: basic@340.edu / I@mABas1cCl!3nt
2. **Employee**: happy@340.edu / I@mAnEmpl0y33  
3. **Manager**: manager@340.edu / I@mAnAdm!n1strat0r

## Application URL
- **Live Site**: https://cse340-kendy.onrender.com

## Week 4 Features
- User registration/login
- Account management 
- Role-based access
- Password validation

## Note
This is a minimal submission with source code only.
Images excluded to meet Canvas file size limits.
